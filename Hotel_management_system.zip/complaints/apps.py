from django.apps import AppConfig


class ComplaintsConfig(AppConfig):
    name = 'complaints'
