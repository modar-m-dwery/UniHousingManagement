from django.apps import AppConfig


class OfficialsConfig(AppConfig):
    name = 'officials'
