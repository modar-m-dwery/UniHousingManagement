FLOOR_OPTIONS = ('Ground', 'First', 'Second', 'Third', 'Fourth')
