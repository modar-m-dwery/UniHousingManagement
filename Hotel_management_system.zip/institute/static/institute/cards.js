$(".card-body").on('click', function () {
  $(this).find('.card-reveal').slideToggle();
})