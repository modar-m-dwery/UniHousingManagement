# __init__.py
default_app_config = 'django_auth.apps.DjangoAuthConfig'