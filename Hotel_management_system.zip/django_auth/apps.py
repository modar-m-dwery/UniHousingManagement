from django.apps import AppConfig


class DjangoAuthConfig(AppConfig):
    name = 'django_auth'

    # def ready(self):
    #     import django_auth.signals
